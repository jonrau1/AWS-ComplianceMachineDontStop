# python 3.6 gd-sorter
import boto3, csv, os, json
s3_resource = boto3.resource('s3')
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    print(event)
    record_count = 0
              
    for record in event['Records']:
              
        bucket = record['s3']['bucket']['name']
        object_key = record['s3']['object']['key']
        partition = '/'.join(object_key.split('/')[2:-1])              
                  
        response = s3_client.get_object(Bucket=bucket, Key=object_key)
        findings = '['+ response['Body'].read().decode('utf-8').replace('}{','},\n{') +']'
                  
        findings_list = json.loads(findings)
        record_count += len(findings_list)
        output = {}
                  
        for item in findings_list:
            if item['detail']['type'] not in output:
                output[item['detail']['type']] = [item]
            else:
                output[item['detail']['type']].append(item)
                  
        for finding_type in output:
            print(object_key.split('/')[-1])
            s3_path = 'raw/by_finding_type/' + '_'.join(finding_type.split('/')) +  '/' + partition  + '/'  + object_key.split('/')[-1] + '.json'
            body = ''
            for version in output[finding_type]:
                body += json.dumps(version) + '\n'
            s3_resource.Bucket(bucket).put_object(Key=s3_path, Body=body)
              
    return 'Processed: ' + str(record_count) + ' logs'